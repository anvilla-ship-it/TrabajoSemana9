package app;

import data.GestorPersonas;
import data.GestorReservas;
import data.GestorTours;
import excepciones.RutInvalidoException;
import model.*;

public class Main {

    public static void main(String[] args) {

        try {

            Direccion direccion1 = new Direccion("Los Alerces 123", "Puerto Varas", "Los Lagos");
            Direccion direccion2 = new Direccion("San Martín 456", "Puerto Montt", "Los Lagos");
            Direccion direccion3 = new Direccion("Costanera 789", "Llanquihue", "Los Lagos");

            Cliente cliente = new Cliente(
                    "Juan Pérez",
                    new Rut("12.345.678-9"),
                    direccion1,
                    "juan@gmail.com"
            );

            Guia guia = new Guia(
                    "Ana Torres",
                    new Rut("15.222.333-4"),
                    direccion2,
                    "Turismo Aventura"
            );

            Proveedor proveedor = new Proveedor(
                    "Carlos Díaz",
                    new Rut("10.555.444-2"),
                    direccion3,
                    "Transportes del Sur"
            );

            Tour tour = new Tour(
                    "Saltos del Petrohué",
                    "Puerto Varas",
                    35000,
                    guia
            );

            Reserva reserva = new Reserva(cliente, tour, 2);

            GestorPersonas gestorPersonas = new GestorPersonas();
            GestorTours gestorTours = new GestorTours();
            GestorReservas gestorReservas = new GestorReservas();

            gestorPersonas.agregarPersona(cliente);
            gestorPersonas.agregarPersona(guia);
            gestorPersonas.agregarPersona(proveedor);

            gestorTours.agregarTour(tour);

            gestorReservas.agregarReserva(reserva);

            System.out.println("===== PERSONAS =====");
            gestorPersonas.mostrarPersonas();

            System.out.println("\n===== TOURS =====");
            gestorTours.mostrarTours();

            System.out.println("\n===== RESERVAS =====");
            gestorReservas.mostrarReservas();

        } catch (RutInvalidoException e) {
            System.out.println(e.getMessage());
        }

    }

}