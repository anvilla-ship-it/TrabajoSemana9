package model;

import interfaces.Registrable;

public class Reserva implements Registrable {

    private Cliente cliente;
    private Tour tour;
    private int cantidadPersonas;

    public Reserva(Cliente cliente, Tour tour, int cantidadPersonas) {
        this.cliente = cliente;
        this.tour = tour;
        this.cantidadPersonas = cantidadPersonas;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Tour getTour() {
        return tour;
    }

    public void setTour(Tour tour) {
        this.tour = tour;
    }

    public int getCantidadPersonas() {
        return cantidadPersonas;
    }

    public void setCantidadPersonas(int cantidadPersonas) {
        this.cantidadPersonas = cantidadPersonas;
    }

    @Override
    public void registrar() {
        System.out.println("Reserva registrada correctamente.");
    }

    @Override
    public void mostrarDatos() {
        System.out.println(this);
    }

    @Override
    public String toString() {
        return "Cliente: " + cliente.getNombre() +
                "\nTour: " + tour.getNombre() +
                "\nCantidad de personas: " + cantidadPersonas;
    }
}