package model;

import excepciones.RutInvalidoException;

public class Rut {

    private String numero;

    public Rut(String numero) throws RutInvalidoException {

        if (numero == null || numero.trim().isEmpty()) {
            throw new RutInvalidoException();
        }

        this.numero = numero;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) throws RutInvalidoException {

        if (numero == null || numero.trim().isEmpty()) {
            throw new RutInvalidoException();
        }

        this.numero = numero;
    }

    @Override
    public String toString() {
        return numero;
    }
}