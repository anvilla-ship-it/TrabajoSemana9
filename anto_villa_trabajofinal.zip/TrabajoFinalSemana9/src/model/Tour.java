package model;

import interfaces.Registrable;

public class Tour implements Registrable {

    private String nombre;
    private String destino;
    private double precio;
    private Guia guia;

    public Tour(String nombre, String destino, double precio, Guia guia) {
        this.nombre = nombre;
        this.destino = destino;
        this.precio = precio;
        this.guia = guia;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public Guia getGuia() {
        return guia;
    }

    public void setGuia(Guia guia) {
        this.guia = guia;
    }

    @Override
    public void registrar() {
        System.out.println("Tour registrado correctamente.");
    }

    @Override
    public void mostrarDatos() {
        System.out.println(this);
    }

    @Override
    public String toString() {
        return "Tour: " + nombre +
                "\nDestino: " + destino +
                "\nPrecio: $" + precio +
                "\nGuía: " + guia.getNombre();
    }
}