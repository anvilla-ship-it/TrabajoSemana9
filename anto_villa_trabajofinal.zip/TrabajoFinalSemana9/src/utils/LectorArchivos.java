package utils;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class LectorArchivos {

    public static void leerArchivo(String ruta) {

        try {
            BufferedReader br = new BufferedReader(new FileReader(ruta));

            String linea;

            while ((linea = br.readLine()) != null) {
                System.out.println(linea);
            }

            br.close();

        } catch (IOException e) {
            System.out.println("Error al leer el archivo.");
        }

    }

}