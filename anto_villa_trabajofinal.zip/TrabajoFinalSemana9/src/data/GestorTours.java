package data;

import java.util.ArrayList;
import model.Tour;

public class GestorTours {

    private ArrayList<Tour> tours;

    public GestorTours() {
        tours = new ArrayList<>();
    }

    public void agregarTour(Tour tour) {
        tours.add(tour);
    }

    public void mostrarTours() {
        for (Tour tour : tours) {
            System.out.println("----------------------------");
            System.out.println(tour);
        }
    }

    public ArrayList<Tour> getTours() {
        return tours;
    }

}