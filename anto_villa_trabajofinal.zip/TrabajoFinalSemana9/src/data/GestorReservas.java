package data;

import java.util.ArrayList;
import model.Reserva;

public class GestorReservas {

    private ArrayList<Reserva> reservas;

    public GestorReservas() {
        reservas = new ArrayList<>();
    }

    public void agregarReserva(Reserva reserva) {
        reservas.add(reserva);
    }

    public void mostrarReservas() {
        for (Reserva reserva : reservas) {
            System.out.println("----------------------------");
            System.out.println(reserva);
        }
    }

    public ArrayList<Reserva> getReservas() {
        return reservas;
    }

}