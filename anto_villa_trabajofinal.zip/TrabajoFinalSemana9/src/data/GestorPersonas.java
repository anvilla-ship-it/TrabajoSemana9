package data;

import java.util.ArrayList;
import model.Persona;

public class GestorPersonas {

    private ArrayList<Persona> personas;

    public GestorPersonas() {
        personas = new ArrayList<>();
    }

    public void agregarPersona(Persona persona) {
        personas.add(persona);
    }

    public void mostrarPersonas() {
        for (Persona persona : personas) {
            System.out.println("----------------------------");
            System.out.println(persona);
        }
    }

    public ArrayList<Persona> getPersonas() {
        return personas;
    }

}